package com.example.myapplication;

public class Workout {

    private String name;
    private String description;

    public static final Workout[] workouts={
            new Workout("1주차","1주차내용"),new Workout("2주차","2주차내용"),new Workout("3주차","3주차내용"),new Workout("4주차","4주차내용")
    };

    private Workout(String name,String description){
        this.name=name;
        this.description=description;
    }

    public String getDescription() {
        return description;
    }

    public String getName(){
        return name;
    }

    public String toString(){
        return this.name;
    }



}
